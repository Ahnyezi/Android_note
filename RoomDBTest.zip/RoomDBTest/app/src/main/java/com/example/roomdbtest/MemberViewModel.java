package com.example.roomdbtest;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/*
<ViewModel>
액티비티의 생명주기와 연결되어
액티비티 실행 중에는 데이터 유지
액티비티 소멸 시 함께 소멸
 */
public class MemberViewModel extends ViewModel {
    private AppDatabase database;
    private MemberDao dao;
    private ExecutorService executorService;//db 백그라운드 작업을 위한 도구(쓰레드)
    private MutableLiveData<ArrayList<Member>> members;//전체 검색용
    private MutableLiveData<Member> member;//1명 검색용

    //getter: activity에 전달
    public MutableLiveData<ArrayList<Member>> getMembers() {
        return members;
    }
    public MutableLiveData<Member> getMember() {
        return member;
    }

    public void create(Context context) {
        database = AppDatabase.getInstance(context);
        dao = database.memberDao();
        executorService = Executors.newSingleThreadExecutor();
        members = new MutableLiveData<>();
        member = new MutableLiveData<>();
    }

    // 전체 검색
    public void getAll() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                members.postValue((ArrayList<Member>)dao.selectAll());//결과를 livedata에 삽입
            }
        });
    }

    // 멤버 1명 검색
    public void getMember(final int _id){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                member.postValue(dao.selectById(_id));//결과를 livedata에 삽입
            }
        });
    }

    public void addMember(final Member m){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.insert(m);
            }
        });
    }

    public void editMember(final Member m){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.update(m);
            }
        });
    }

    public void delMember(final Member m){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.delete(m);
            }
        });
    }

    //viewModel이 제거될 때 호출
    //view model은 액티비티와 생명주기를 같이 하기 때문에 액티비티가 종료될 때 호출된다.
    @Override
    protected void onCleared() {
        super.onCleared();
        database.close();//사용한 db 닫기
        System.out.println("db close");
    }
}
