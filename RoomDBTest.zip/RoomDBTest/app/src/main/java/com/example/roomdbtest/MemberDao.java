package com.example.roomdbtest;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

//JPARepository 역할
@Dao
public interface MemberDao {
    @Insert
    void insert(Member m);

    @Query("select * from member")
    List<Member> selectAll();

    @Query("select * from member where _id=(:id)")//_id 처럼 언더바 쓰면 오류남
    Member selectById(int id);

    @Delete
    void delete(Member m);

    @Update
    void update(Member m);
}
