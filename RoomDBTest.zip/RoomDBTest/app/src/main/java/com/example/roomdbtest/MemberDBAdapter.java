package com.example.roomdbtest;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MemberDBAdapter {
    private AppDatabase database;
    private MemberDao dao;
    private ExecutorService executorService;//db 백그라운드 작업을 위한 도구(쓰레드)
    private Handler handler;//UI thread와 db작업 thread 사이에 메시지 교환을 돕는 역할.

    public MemberDBAdapter(Context context, Handler handler) {
        this.handler = handler;//한쪽에서 만들어서 두 측에서 함께 쓴다.
        database = AppDatabase.getInstance(context);
        dao = database.memberDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    //1. 전체 검색
    public void getAll() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();//메세지를 담을 객체 생성
                msg.what = 0;   //메세지 종류 설정.(반대편에 반환할 값을 알려주는 역할. list<Member> or Member...)
                                //msg.arg1 : 메세지 값이 int 타입인 경우
                                //msg.obj : 메세지 값이 클래스 타입인 경우
                msg.obj = (ArrayList<Member>) dao.selectAll();
                handler.sendMessage(msg);//handler를 통해 main activity에 전달.
            }
        });
    }

    //2. 멤버 1명 검색
    public void getMember(final int _id){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                msg.what = 1;
                msg.obj = dao.selectById(_id);
                handler.sendMessage(msg);
            }
        });
    }

    public void addMember(final Member m){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.insert(m);
            }
        });
    }


    public void editMember(final Member m){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.update(m);
            }
        });
    }

    public void delMember(final Member m){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.delete(m);
            }
        });
    }
}
