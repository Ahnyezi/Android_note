package com.example.roomdbtest;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

//VO 클래스(테이블)
@Entity
public class Member {
    @PrimaryKey(autoGenerate = true)
    public int _id;
    public String name;
    public String tel;

    public Member() {
    }

    public Member(int _id, String name, String tel) {
        this._id = _id;
        this.name = name;
        this.tel = tel;
    }

    @Override
    public String toString() {
        return
                "_id=" + _id + "     name= " + name + "      tel=" + tel;
    }
}
