package com.example.roomdbtest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText name_et;
    private EditText tel_et;
    private ListView listView;
    private ArrayAdapter<Member> adapter;
    private ArrayList<Member> list;
    private Handler handler;
    private MemberDBAdapter db;
    private Member m;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name_et = findViewById(R.id.name_et);
        tel_et = findViewById(R.id.tel_et);
        listView = findViewById(R.id.lv1);
        list = new ArrayList<>();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        //handler == msg queue(쓰레드 간에 통신을 할 수 있게)
        handler = new Handler(Looper.getMainLooper()){//looper: 내부 loop (내부에 메세지가 존재하면 계속 반복)
            //메세지가 도착하면 자동으로 호출됨
            @Override
            public void handleMessage(@NonNull Message msg) {
                if(msg.what==0){//전체 검색
                    ArrayList<Member> tmp = (ArrayList<Member>) msg.obj;
                    list.clear();
                    list.addAll(tmp);
                    adapter.notifyDataSetChanged();
                }else{//msg.what==1: 멤버 1명 검색
                    Member x = (Member) msg.obj;
                    name_et.setText(x.name);
                    tel_et.setText(x.tel);
                }
            }
        };
        db = new MemberDBAdapter(this,handler);
        registerForContextMenu(listView);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                db.getMember(list.get(i)._id);//list i번째 방의 id값으로 검색
            }
        });
    }


    public void onSave(View view){
        String n = name_et.getText().toString();
        String t = tel_et.getText().toString();
        db.addMember(new Member(0,n,t));
        name_et.setText("");
        tel_et.setText("");
        db.getAll();
    }
    public void onEdit(View view){
        if(m!=null){
            m.name = name_et.getText().toString();
            m.tel = tel_et.getText().toString();
            db.editMember(m);
            db.getAll();
            m = null;
            name_et.setText("");
            tel_et.setText("");
        }
    }

    //화면 시작되자마자 실행되는 코드
    @Override
    protected void onPostResume() {
        super.onPostResume();
        db.getAll();//onCreate에 넣으면 싱크 안맞음
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,1,0,"edit");
        menu.add(0,2,0,"delete");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info =  (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int idx = info.position;//길게 누른 위치값
        m = list.get(idx);
        switch(item.getItemId()){
            case 1:
                name_et.setText(m.name);
                tel_et.setText(m.tel);
                break;
            case 2:
                db.delMember(m);
                db.getAll();
                m = null;
                break;
        }
        return true;
    }
}