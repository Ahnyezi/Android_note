package com.example.roomdbtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

import static java.lang.Thread.sleep;

public class LiveDataTestActivity extends AppCompatActivity {
    private TextView tv;
    private MutableLiveData<String> liveData;//liveData == handler

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_data_test);
        tv = findViewById(R.id.textView);
        liveData = new MutableLiveData<>();

        liveData.observe(this, new Observer<String>() {//observer가 데이터 변경을 계속 관찰
            @Override
            public void onChanged(String s) {//감지가 되면 자동으로 호출을 하여 view에 적용시킴
                tv.setText(s);
            }
        });

        new Thread(){
            @Override
            public void run(){
                ArrayList<String> list =  new ArrayList<>();
                list.add("aaa");
                list.add("bbb");
                list.add("ccc");
                for(int i=0;i<100;i++){
                    //liveData.setValue("asdf");  // setValue(): main 쓰레드에서 값을 저장할 때 사용. 그런데 파생 쓰레드에선 쓰지 못한다.
                    liveData.postValue(list.get(i % 3));  // => 파생 쓰레드에서 넣어준 값을 저장하려면 postValue() 사용!
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }
}