package com.example.storagetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class MainActivity2 extends AppCompatActivity {
    private EditText content;
    private EditText content2;
    private FileOutputStream fo;
    private FileInputStream fi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        content = findViewById(R.id.et1);
        content2 = findViewById(R.id.et2);
    }

    // 1. 파일 쓰기
    public void onSave(View view){
        try {
            /*
            <파일 저장 경로>
            android는 보안을 위해서
            데이터/파일을 공유하지 않음.
            현재 프로젝트에서만 사용할 수있게
            해당 프로젝트 내부에 모든 데이터/파일 저장
            */
            fo = openFileOutput("file.txt",MODE_APPEND);//파일명, 오픈 모드(이어쓰기)
            fo.write((content.getText().toString()+"\n").getBytes());//현재패키지에 files라는 디렉토리를 만들어서 저장.
            System.out.println("저장 완료");
            fo.close();
            content.setText("");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 2. 파일 읽기
    public void onRead(View view){
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[40];
        try {
            fi = openFileInput("file.txt");
            while((fi.read(buf,0,40))!=-1){
                String str = new String(buf);
                sb.append(str);
                if(fi.available()<40){ //이전에 쓴 쓰레기값 제거 //available(): 잔량 체크
                    Arrays.fill(buf,0,40,(byte)' ');
                }
                fi.close();
                content2.setText(sb.toString());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}