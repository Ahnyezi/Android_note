package com.example.storagetest;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Member.class}, version=1)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase appDatabase;//database
    public abstract MemberDao memberDao();//Repository 객체

    public static AppDatabase getInstance(Context context){
        /*
        db에는 커넥션 생성 시간이 젤 오래 걸림
        따라서 매번 불필요하게 생성하지 않고
        싱글톤으로 하나만 만들어서 클래스 내에서 공유한다.
         */
        if(appDatabase==null){
            appDatabase = Room.databaseBuilder(context, AppDatabase.class, "app_db")
                    .allowMainThreadQueries()//원래 room db 작업은 ui thread에서 실행할 수 없으나, 이를 허용하는 코드
                    .build();
        }
        return appDatabase;
    }

    public static void delDB(){
        appDatabase = null;
    }
}
