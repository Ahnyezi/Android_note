package com.example.storagetest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBAdapter {
    /*
    SQLite는 파일 기반의 관계형 데이터 베이스
    따라서 먼저 db파일을 생성하고,
    그 안에서 테이블을 생성하여 사용한다.
    */

    //<멤버변수>
    private static final String DB = "MyDB.db"; // DB 파일명
    private static final String DB_TABLE = "MyTable"; // 테이블명
    private static final String ID = "_id"; // 컬럼명
    private static final String NAME = "name"; // 컬럼명
    private static final int DB_VERS = 1; // DB 파일 버전

    private SQLiteDatabase mdb;//db 파일 처리 객체(가장 중요)
    private final Context context;
    private MyHelper mHelper;

    public MyDBAdapter(Context context) {
        this.context = context;
        //helper 객체 생성
        mHelper = new MyHelper(context, DB, null, DB_VERS);
        //설정한 버전이 맞지 않으면 onUpgrade 호출된다.
    }

    //helper 객체로 db파일 오픈
    //dao와 동일한 역할
    public void open() throws SQLiteException {
        try {
            mdb = mHelper.getWritableDatabase();//읽고 쓰기 모드로 오픈
        } catch (SQLiteException ex) {
            mdb = mHelper.getReadableDatabase();//문제 있을 경우, 읽기 전용 모드로 오픈
        }
    }

    //db 파일 닫기
    public void close() {
        mdb.close();
    }

    // <DML>
    // a. insert
    public long insertData(String name) {
        ContentValues cv = new ContentValues();//ContentValues: 값을 담는 그릇
        cv.put(NAME, name);//insert할 컬럼명, 값
        return mdb.insert(DB_TABLE, null, cv);
    }

    // b. delete
    public int removeData(long index) {
        return mdb.delete(DB_TABLE, ID + "=" + index, null);
    }

    // c. update
    public int updateData(long index, String name) {
        String where = ID + " = " + index;
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        return mdb.update(DB_TABLE, cv, where, null);
    }

    // d. 전체 검색
    public Cursor getAll() {//Cursor(==resultset)
        //query(): 검색기능
        //param: 테이블 명, 검색할 컬럼명...
        return mdb.query(DB_TABLE, new String[] { ID, NAME}, null, null, null, null, null);
    }


    // <SQLiteOpenHelper 기능>
    private static class MyHelper extends SQLiteOpenHelper {

        private static final String DB_CREATE = "create table " + DB_TABLE + " (" + ID +
                " integer primary key autoincrement, " + NAME + " text not null );";

        //a. Helper 객체 생성: context 객체, db파일 이름, cursor 관리 팩토리 객체(안쓰면 null), db파일 버전
        public MyHelper(Context context, String name,
                        SQLiteDatabase.CursorFactory factory, int version) {

            super(context, name, factory, version);
        }

        // b. 테이블 생성: db파일 생성될 때 한번만 호출된다.
        @Override
        public void onCreate(SQLiteDatabase db) {//param으로 db 조작 객체를 받아와서
            db.execSQL(DB_CREATE);
        }

        // c. 테이블 업그레이드: 버전이 맞지 않을 때 호출된다.
        @Override
        public void onUpgrade(SQLiteDatabase db, int oVers, int nVers) {
            db.execSQL("DROP TABLE IF EXISTS " + DB_TABLE);//현재 테이블을 삭제
            onCreate(db);//새로 생성
        }
    }

}
