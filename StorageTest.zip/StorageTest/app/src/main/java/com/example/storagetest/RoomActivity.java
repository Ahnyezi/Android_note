package com.example.storagetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class RoomActivity extends AppCompatActivity {
    private AppDatabase database;
    private MemberDao dao;
    private ArrayList<Member> list;
    private ArrayAdapter<Member> adapter;
    private EditText name_et;
    private EditText tel_et;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);
        name_et = findViewById(R.id.name_et);
        tel_et = findViewById(R.id.tel_et);
        listView = findViewById(R.id.lv2);

        database = AppDatabase.getInstance(getApplicationContext());
        dao = database.memberDao();

        list = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        getAll();
    }

    //room은 기본적으로 ui쓰레드(메인쓰레드)에서 db작업하는 것을 허용하지 않음.
    //따라서 AppDatabase에서 allowmainthreadquery를 설정해줌으로써 억지로 db작업을 가능케 함.
    public void getAll(){
        list.clear();
        ArrayList<Member> tmp = (ArrayList<Member>) dao.selectAll();//allowmainthreadquery로 허용
        if(tmp==null){
            return;
        }
        list.addAll(tmp);
        System.out.println(list);
        adapter.notifyDataSetChanged();
    }
    public void onSave(View view){
        String n = name_et.getText().toString();
        String t = tel_et.getText().toString();
        dao.insert(new Member(0,n,t));//allowmainthreadquery로 허용
        getAll();
    }
}