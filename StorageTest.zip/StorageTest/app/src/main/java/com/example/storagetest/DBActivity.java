package com.example.storagetest;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

class Names{
    public int _id;
    public String name;

    public Names() {
    }

    public Names(int _id, String name) {
        this._id = _id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Names{" +
                "_id=" + _id +
                ", name='" + name + '\'' +
                '}';
    }
}

public class DBActivity extends AppCompatActivity {
    private MyDBAdapter dbAdapter;
    private ArrayList<Names> list; //db 내용 저장
    private ArrayAdapter<Names> adapter;
    private ListView listView;
    private Cursor cursor;//검색 결과 담는 그릇
    private EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_b);
        listView  = findViewById(R.id.lv1);
        name  = findViewById(R.id.name);

        dbAdapter = new MyDBAdapter(getApplicationContext());//getApplicationContext(): 현재 프로그램의 컨텍스트 get. (==this)
        list = new ArrayList<>();

        adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);
        DBinit();
    }

    //데이터 베이스 open
    public void DBinit(){
        dbAdapter.open();
        makeList();
    }

    //데이터 추출하여 list 갱신
    public void makeList(){
        list.clear();;
        cursor = dbAdapter.getAll();
        if(cursor.moveToFirst()){//첫째줄로 이동
            do{
                //*주의) 컬럼의 idx는 0부터 시작
                list.add(new Names(cursor.getInt(0),cursor.getString(1)));//0번과 1번 컬럼값 setting
            } while(cursor.moveToNext());//다음줄로 이동
        }
        adapter.notifyDataSetChanged();//뷰 갱신
    }

    //데이터 추가
    public void onSave(View view){
        String n = name.getText().toString();
        dbAdapter.insertData(n);//insert 호출하여 데이터 저장
        makeList();
    }

    //현재 activity 종료
    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbAdapter.close();//db close
    }
}