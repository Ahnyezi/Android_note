package com.example.storagetest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.prefs.Preferences;

public class MainActivity extends AppCompatActivity {
    private String id;
    private EditText id_et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id_et = findViewById(R.id.id_et);

        if(id==null){
            SharedPreferences pref = getSharedPreferences("idcheck",MODE_PRIVATE);
            id = pref.getString("id",null);//key, default value
            if(id == null){
                Toast.makeText(this,"id를 등록하시오.",Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this,id+"로 로그인된 상태입니다.",Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void onBtn1(View view){
        String i = id_et.getText().toString();
        SharedPreferences pref = getSharedPreferences("idcheck",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("id",i);
        editor.commit();//id라는 key로 preferences 파일에 저장.
        id_et.setText("");
    }

    public void onBtn2(View view){
        SharedPreferences pref = getSharedPreferences("idcheck",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove("id");
        editor.commit();
    }
}