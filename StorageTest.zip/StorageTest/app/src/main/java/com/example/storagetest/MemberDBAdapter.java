package com.example.storagetest;

import java.util.List;

public class MemberDBAdapter {
    private AppDatabase db;
    private MemberDao dao;

    public MemberDBAdapter() {
        dao = db.memberDao();
    }

    public void addMember(Member m){
        dao.insert(m);
    }

    public List<Member> getAll(){
        return dao.selectAll();
    }

    public void editMember(Member m){
        dao.update(m);
    }

    public void delMember(Member m){
        dao.delete(m);
    }
}
